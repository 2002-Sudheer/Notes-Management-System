<?php

$c = mysqli_connect('localhost','root','','study');

if(!$c)
{
    echo "<h1><center>Error</center></h1>";
    exit();
}

?>